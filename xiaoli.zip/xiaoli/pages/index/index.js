Page({
  data: {
    shopList: []
  },
  listData: {
    page: 1, // 当前页面
    pageSize: 10, // 请求数据的数量
    total: 0 // 总数据量
  },
  // 小程序生命周期函数，页面加载时调用
  onLoad() {
    // 获取店铺数据
    this.getShopList()
  },
  // 获取店铺数据
  getShopList() {
    // 提示框
    wx.showLoading({
      title: '正在加载...',
    })
    // 发起网络请求
    wx.request({
      url: 'http://127.0.0.1:3000/data',
      method: 'GET',
      data: {
        page: this.listData.page,
        pageSize: this.listData.pageSize
      },
      // 请求成功
      success: res => {
        // 打印返回的对象到控制台
        console.log(res)
        // 设置shopList数据
        this.setData({
          // 将原数据和新数据拼接后给shopList
          shopList: [...this.data.shopList, ...res.data]
        })
        this.listData.total = Number(res.header['X-Total-Count'])
      },
      complete: () => {
        // 隐藏提示框
        wx.hideLoading()
      }
    })
  },
  // 上拉触底
  onReachBottom() {
    // 页面自增1
    ++this.listData.page
    // 获取新的数据
    this.getShopList()
  },
  // 下拉刷新
  onPullDownRefresh() {
    // 重置基本数据
    this.setData({
      shopList: []
    })
    this.listData.page = 1 // 当前页面
    this.listData.total = 0 // 总数据量
    // 重新获取数据
    this.getShopList()
  }
})